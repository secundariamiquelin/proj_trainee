require('dotenv').config();
const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para aceitar JSON
app.use(express.json());

// Rota Principal
app.get('/', (req, res) => {
  res.json({
    mensagem: 'Bem-vindo à API do projeto!',
    status: 'Operacional',
    sprint: 1
  });
});

// Rota simulando a entrega de uma Feature (Ex: Autenticação)
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  
  if (email && password) {
    res.json({ 
      sucesso: true, 
      token: 'jwt_token_simulado_123456789' 
    });
  } else {
    res.status(400).json({ 
      erro: 'Email e senha são obrigatórios.' 
    });
  }
});

// Inicialização do Servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando perfeitamente na porta ${PORT}`);
  console.log(`👉 Acesse: http://localhost:${PORT}`);
});